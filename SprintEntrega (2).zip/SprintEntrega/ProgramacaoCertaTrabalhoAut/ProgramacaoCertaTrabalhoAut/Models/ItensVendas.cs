﻿namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class ItensVendas : VendasC
    {
        public Guid ItensVendasID { get; set; }
        public Guid ProdutosId { get; set; }
        public Produtos? Produtos { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade{ get; set; }  
        public Guid VendasCId { get; set; }
        public VendasC? vendasC { get; set; }
       
        
    }
}
