﻿using System.ComponentModel;

namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class VendasC
    {
        public Guid VendasCId { get; set; }
        [DisplayName("Número Nota de Venda")]
       
        public int NumeroVendas { get; set;}
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }
        public Guid ClientesId { get; set; }
        public Clientes? Clientes { get; set; }



    }
}
