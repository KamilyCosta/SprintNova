﻿using System.ComponentModel;

namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class Relatorio
    {
        public Guid RelatorioId { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public int Quantidade { get; set; }
        [DisplayName("Preço")]
        public decimal Preco { get; set; }
    }
}
