﻿namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class MovimenItem
    {
        public Guid MovimenItemId { get; set; }
        public Guid ProdutoId { get; set; }
        public Produtos? Produtos { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }
        public Guid MovimentacaoId { get; set; }
        public Movimentacao? Movimentacao { get; set; }

    }
}
