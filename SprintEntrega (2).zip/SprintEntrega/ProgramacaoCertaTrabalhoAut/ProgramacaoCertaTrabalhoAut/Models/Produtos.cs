﻿using System.ComponentModel;

namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class Produtos 
    {
        public Guid ProdutosId { get; set; }
        public string Nome { get; set;}
        public int Estoque { get; set;}
        [DisplayName("Preço")]
        public decimal Preco { get; set;}
        public string CategoriaId { get; set;}
         
        public Categoria? Categoria { get; set;}

        public Guid FornecedorId { get; set;}
        public Fornecedor? Fornecedor { get; set;}

    }
}
