﻿namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class MaterialC
    {
        public Guid MaterialCId { get; set; }
        public string Nome { get; set;}
    }
}
