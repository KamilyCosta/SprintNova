﻿using System.ComponentModel;

namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class Fornecedor
    {
        public Guid FornecedorId { get; set; }
        public string Nome { get; set; }
        [DisplayName("CNPJ")]
        public int Cnpj { get; set; }
    }
}
