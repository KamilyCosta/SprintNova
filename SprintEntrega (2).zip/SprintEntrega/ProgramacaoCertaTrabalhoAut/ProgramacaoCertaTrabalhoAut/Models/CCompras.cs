﻿using System.ComponentModel;

namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class CCompras
    {
        public Guid CComprasId { get; set; }
        [DisplayName("Nota de Compras")]
        public int NotaCompras { get; set; }
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }
        public int  Quantidade { get; set; }
        [DisplayName("Preço")]
        public decimal Preco { get; set; }


    }
}
