﻿using System.ComponentModel;

namespace ProgramacaoCertaTrabalhoAut.Models
{
    public class Movimentacao
    {
        public Guid MovimentacaoId { get; set; }
        [DisplayName("Nota Fiscal")]
        public int NotaFiscal { get; set; }
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }
        [DisplayName("Tipo de Movimentação")]
        public string TipoMov { get; set; }
        public string Produto { get; set; }
        public int Quantidade { get; set; }
        [DisplayName("Preço")]
        public decimal Preco { get; set; }
    }
}
