﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProgramacaoCertaTrabalhoAut.Data;
using ProgramacaoCertaTrabalhoAut.Models;

namespace ProgramacaoCertaTrabalhoAut.Controllers
{
    public class ItensVendasController : Controller
    {
        private readonly MaterialContext _context;

        public ItensVendasController(MaterialContext context)
        {
            _context = context;
        }

        // GET: ItensVendas
        public async Task<IActionResult> Index()
        {
            var materialContext = _context.ItensVendas.Include(i => i.Clientes).Include(i => i.Produtos);
            return View(await materialContext.ToListAsync());
        }

        // GET: ItensVendas/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.ItensVendas == null)
            {
                return NotFound();
            }

            var itensVendas = await _context.ItensVendas
                .Include(i => i.Clientes)
                .Include(i => i.Produtos)
                .FirstOrDefaultAsync(m => m.VendasCId == id);
            if (itensVendas == null)
            {
                return NotFound();
            }

            return View(itensVendas);
        }

        // GET: ItensVendas/Create
        public IActionResult Create()
        {
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "ClientesId");
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId");
            return View();
        }

        // POST: ItensVendas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ItensVendasID,ProdutosId,Preco,Quantidade,VendasCId,NumeroVendas,DataHora,ClientesId")] ItensVendas itensVendas)
        {
            if (ModelState.IsValid)
            {
                itensVendas.VendasCId = Guid.NewGuid();
                _context.Add(itensVendas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "ClientesId", itensVendas.ClientesId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itensVendas.ProdutosId);
            return View(itensVendas);
        }

        // GET: ItensVendas/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.ItensVendas == null)
            {
                return NotFound();
            }

            var itensVendas = await _context.ItensVendas.FindAsync(id);
            if (itensVendas == null)
            {
                return NotFound();
            }
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "ClientesId", itensVendas.ClientesId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itensVendas.ProdutosId);
            return View(itensVendas);
        }

        // POST: ItensVendas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("ItensVendasID,ProdutosId,Preco,Quantidade,VendasCId,NumeroVendas,DataHora,ClientesId")] ItensVendas itensVendas)
        {
            if (id != itensVendas.VendasCId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(itensVendas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ItensVendasExists(itensVendas.VendasCId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "ClientesId", itensVendas.ClientesId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itensVendas.ProdutosId);
            return View(itensVendas);
        }

        // GET: ItensVendas/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.ItensVendas == null)
            {
                return NotFound();
            }

            var itensVendas = await _context.ItensVendas
                .Include(i => i.Clientes)
                .Include(i => i.Produtos)
                .FirstOrDefaultAsync(m => m.VendasCId == id);
            if (itensVendas == null)
            {
                return NotFound();
            }

            return View(itensVendas);
        }

        // POST: ItensVendas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.ItensVendas == null)
            {
                return Problem("Entity set 'MaterialContext.ItensVendas'  is null.");
            }
            var itensVendas = await _context.ItensVendas.FindAsync(id);
            if (itensVendas != null)
            {
                _context.ItensVendas.Remove(itensVendas);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ItensVendasExists(Guid id)
        {
          return (_context.ItensVendas?.Any(e => e.VendasCId == id)).GetValueOrDefault();
        }
    }
}
