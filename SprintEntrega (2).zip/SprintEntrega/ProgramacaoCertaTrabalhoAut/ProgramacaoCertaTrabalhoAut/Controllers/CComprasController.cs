﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProgramacaoCertaTrabalhoAut.Data;
using ProgramacaoCertaTrabalhoAut.Models;

namespace ProgramacaoCertaTrabalhoAut.Controllers
{
    [Authorize(Roles = "Admin, Operador")]
    public class CComprasController : Controller
    {
        private readonly MaterialContext _context;

        public CComprasController(MaterialContext context)
        {
            _context = context;
        }

        // GET: CCompras
        public async Task<IActionResult> Index()
        {
              return _context.CCompras != null ? 
                          View(await _context.CCompras.ToListAsync()) :
                          Problem("Entity set 'MaterialContext.CCompras'  is null.");
        }

        // GET: CCompras/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.CCompras == null)
            {
                return NotFound();
            }

            var cCompras = await _context.CCompras
                .FirstOrDefaultAsync(m => m.CComprasId == id);
            if (cCompras == null)
            {
                return NotFound();
            }

            return View(cCompras);
        }

        // GET: CCompras/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CCompras/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CComprasId,NotaCompras,DataHora,Quantidade,Preco")] CCompras cCompras)
        {
            if (ModelState.IsValid)
            {
                cCompras.CComprasId = Guid.NewGuid();
                _context.Add(cCompras);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cCompras);
        }

        // GET: CCompras/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.CCompras == null)
            {
                return NotFound();
            }

            var cCompras = await _context.CCompras.FindAsync(id);
            if (cCompras == null)
            {
                return NotFound();
            }
            return View(cCompras);
        }

        // POST: CCompras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("CComprasId,NotaCompras,DataHora,Quantidade,Preco")] CCompras cCompras)
        {
            if (id != cCompras.CComprasId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cCompras);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CComprasExists(cCompras.CComprasId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cCompras);
        }

        // GET: CCompras/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.CCompras == null)
            {
                return NotFound();
            }

            var cCompras = await _context.CCompras
                .FirstOrDefaultAsync(m => m.CComprasId == id);
            if (cCompras == null)
            {
                return NotFound();
            }

            return View(cCompras);
        }

        // POST: CCompras/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.CCompras == null)
            {
                return Problem("Entity set 'MaterialContext.CCompras'  is null.");
            }
            var cCompras = await _context.CCompras.FindAsync(id);
            if (cCompras != null)
            {
                _context.CCompras.Remove(cCompras);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CComprasExists(Guid id)
        {
          return (_context.CCompras?.Any(e => e.CComprasId == id)).GetValueOrDefault();
        }
    }
}
