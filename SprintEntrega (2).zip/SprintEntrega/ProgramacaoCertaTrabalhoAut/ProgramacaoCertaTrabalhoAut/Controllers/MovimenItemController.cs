﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProgramacaoCertaTrabalhoAut.Data;
using ProgramacaoCertaTrabalhoAut.Models;

namespace ProgramacaoCertaTrabalhoAut.Controllers
{
    public class MovimenItemController : Controller
    {
        private readonly MaterialContext _context;

        public MovimenItemController(MaterialContext context)
        {
            _context = context;
        }

        // GET: MovimenItem
        public async Task<IActionResult> Index()
        {
            var materialContext = _context.MovimenItem.Include(m => m.Movimentacao);
            return View(await materialContext.ToListAsync());
        }

        // GET: MovimenItem/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.MovimenItem == null)
            {
                return NotFound();
            }

            var movimenItem = await _context.MovimenItem
                .Include(m => m.Movimentacao)
                .FirstOrDefaultAsync(m => m.MovimenItemId == id);
            if (movimenItem == null)
            {
                return NotFound();
            }

            return View(movimenItem);
        }

        // GET: MovimenItem/Create
        public IActionResult Create()
        {
            ViewData["MovimentacaoId"] = new SelectList(_context.Movimentacao, "MovimentacaoId", "MovimentacaoId");
            return View();
        }

        // POST: MovimenItem/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MovimenItemId,ProdutoId,Preco,Quantidade,MovimentacaoId")] MovimenItem movimenItem)
        {
            if (ModelState.IsValid)
            {
                movimenItem.MovimenItemId = Guid.NewGuid();
                _context.Add(movimenItem);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MovimentacaoId"] = new SelectList(_context.Movimentacao, "MovimentacaoId", "MovimentacaoId", movimenItem.MovimentacaoId);
            return View(movimenItem);
        }

        // GET: MovimenItem/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.MovimenItem == null)
            {
                return NotFound();
            }

            var movimenItem = await _context.MovimenItem.FindAsync(id);
            if (movimenItem == null)
            {
                return NotFound();
            }
            ViewData["MovimentacaoId"] = new SelectList(_context.Movimentacao, "MovimentacaoId", "MovimentacaoId", movimenItem.MovimentacaoId);
            return View(movimenItem);
        }

        // POST: MovimenItem/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("MovimenItemId,ProdutoId,Preco,Quantidade,MovimentacaoId")] MovimenItem movimenItem)
        {
            if (id != movimenItem.MovimenItemId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(movimenItem);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MovimenItemExists(movimenItem.MovimenItemId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MovimentacaoId"] = new SelectList(_context.Movimentacao, "MovimentacaoId", "MovimentacaoId", movimenItem.MovimentacaoId);
            return View(movimenItem);
        }

        // GET: MovimenItem/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.MovimenItem == null)
            {
                return NotFound();
            }

            var movimenItem = await _context.MovimenItem
                .Include(m => m.Movimentacao)
                .FirstOrDefaultAsync(m => m.MovimenItemId == id);
            if (movimenItem == null)
            {
                return NotFound();
            }

            return View(movimenItem);
        }

        // POST: MovimenItem/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.MovimenItem == null)
            {
                return Problem("Entity set 'MaterialContext.MovimenItem'  is null.");
            }
            var movimenItem = await _context.MovimenItem.FindAsync(id);
            if (movimenItem != null)
            {
                _context.MovimenItem.Remove(movimenItem);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MovimenItemExists(Guid id)
        {
          return (_context.MovimenItem?.Any(e => e.MovimenItemId == id)).GetValueOrDefault();
        }
    }
}
