﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProgramacaoCertaTrabalhoAut.Data;
using ProgramacaoCertaTrabalhoAut.Models;

namespace ProgramacaoCertaTrabalhoAut.Controllers
{
    public class RelatorioController : Controller
    {
        private readonly MaterialContext _context;

        public RelatorioController(MaterialContext context)
        {            
            _context = context;
        }
        public IActionResult Index()
        {
            var MaterialContext = _context.Produtos.Include(p => p.Categoria).Include(p => p.Fornecedor);
            return View(MaterialContext);
        }

        public IActionResult RelMov() 
        {
           return View();
        }
    }
}
