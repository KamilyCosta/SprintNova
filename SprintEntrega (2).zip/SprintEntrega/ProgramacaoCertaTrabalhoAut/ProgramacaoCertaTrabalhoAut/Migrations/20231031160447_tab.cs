﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProgramacaoCertaTrabalhoAut.Migrations
{
    /// <inheritdoc />
    public partial class tab : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbCategoria",
                columns: table => new
                {
                    CategoriaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbCategoria", x => x.CategoriaId);
                });

            migrationBuilder.CreateTable(
                name: "tbCCompras",
                columns: table => new
                {
                    CComprasId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NotaCompras = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbCCompras", x => x.CComprasId);
                });

            migrationBuilder.CreateTable(
                name: "tbClientes",
                columns: table => new
                {
                    ClientesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Endereco = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Telefone = table.Column<int>(type: "int", nullable: false),
                    Cpf = table.Column<int>(type: "int", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DataNascimento = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbClientes", x => x.ClientesId);
                });

            migrationBuilder.CreateTable(
                name: "tbFornecedor",
                columns: table => new
                {
                    FornecedorId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cnpj = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbFornecedor", x => x.FornecedorId);
                });

            migrationBuilder.CreateTable(
                name: "tbMovimentacao",
                columns: table => new
                {
                    MovimentacaoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NotaFiscal = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TipoMov = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Produto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbMovimentacao", x => x.MovimentacaoId);
                });

            migrationBuilder.CreateTable(
                name: "tbRelatorioP",
                columns: table => new
                {
                    RelatorioId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Categoria = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbRelatorioP", x => x.RelatorioId);
                });

            migrationBuilder.CreateTable(
                name: "tbCVendas",
                columns: table => new
                {
                    VendasCId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NumeroVendas = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClientesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbCVendas", x => x.VendasCId);
                    table.ForeignKey(
                        name: "FK_tbCVendas_tbClientes_ClientesId",
                        column: x => x.ClientesId,
                        principalTable: "tbClientes",
                        principalColumn: "ClientesId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbProdutos",
                columns: table => new
                {
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Estoque = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CategoriaId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CategoriaId1 = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    FornecedorId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbProdutos", x => x.ProdutosId);
                    table.ForeignKey(
                        name: "FK_tbProdutos_tbCategoria_CategoriaId1",
                        column: x => x.CategoriaId1,
                        principalTable: "tbCategoria",
                        principalColumn: "CategoriaId");
                    table.ForeignKey(
                        name: "FK_tbProdutos_tbFornecedor_FornecedorId",
                        column: x => x.FornecedorId,
                        principalTable: "tbFornecedor",
                        principalColumn: "FornecedorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbItensVendas",
                columns: table => new
                {
                    VendasCId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ItensVendasID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    VendasCId1 = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbItensVendas", x => x.VendasCId);
                    table.ForeignKey(
                        name: "FK_tbItensVendas_tbCVendas_VendasCId",
                        column: x => x.VendasCId,
                        principalTable: "tbCVendas",
                        principalColumn: "VendasCId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbItensVendas_tbCVendas_VendasCId1",
                        column: x => x.VendasCId1,
                        principalTable: "tbCVendas",
                        principalColumn: "VendasCId");
                    table.ForeignKey(
                        name: "FK_tbItensVendas_tbProdutos_ProdutosId",
                        column: x => x.ProdutosId,
                        principalTable: "tbProdutos",
                        principalColumn: "ProdutosId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbMovimenItem",
                columns: table => new
                {
                    MovimenItemId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    MovimentacaoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbMovimenItem", x => x.MovimenItemId);
                    table.ForeignKey(
                        name: "FK_tbMovimenItem_tbMovimentacao_MovimentacaoId",
                        column: x => x.MovimentacaoId,
                        principalTable: "tbMovimentacao",
                        principalColumn: "MovimentacaoId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbMovimenItem_tbProdutos_ProdutosId",
                        column: x => x.ProdutosId,
                        principalTable: "tbProdutos",
                        principalColumn: "ProdutosId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_tbCVendas_ClientesId",
                table: "tbCVendas",
                column: "ClientesId");

            migrationBuilder.CreateIndex(
                name: "IX_tbItensVendas_ProdutosId",
                table: "tbItensVendas",
                column: "ProdutosId");

            migrationBuilder.CreateIndex(
                name: "IX_tbItensVendas_VendasCId1",
                table: "tbItensVendas",
                column: "VendasCId1");

            migrationBuilder.CreateIndex(
                name: "IX_tbMovimenItem_MovimentacaoId",
                table: "tbMovimenItem",
                column: "MovimentacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_tbMovimenItem_ProdutosId",
                table: "tbMovimenItem",
                column: "ProdutosId");

            migrationBuilder.CreateIndex(
                name: "IX_tbProdutos_CategoriaId1",
                table: "tbProdutos",
                column: "CategoriaId1");

            migrationBuilder.CreateIndex(
                name: "IX_tbProdutos_FornecedorId",
                table: "tbProdutos",
                column: "FornecedorId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbCCompras");

            migrationBuilder.DropTable(
                name: "tbItensVendas");

            migrationBuilder.DropTable(
                name: "tbMovimenItem");

            migrationBuilder.DropTable(
                name: "tbRelatorioP");

            migrationBuilder.DropTable(
                name: "tbCVendas");

            migrationBuilder.DropTable(
                name: "tbMovimentacao");

            migrationBuilder.DropTable(
                name: "tbProdutos");

            migrationBuilder.DropTable(
                name: "tbClientes");

            migrationBuilder.DropTable(
                name: "tbCategoria");

            migrationBuilder.DropTable(
                name: "tbFornecedor");
        }
    }
}
