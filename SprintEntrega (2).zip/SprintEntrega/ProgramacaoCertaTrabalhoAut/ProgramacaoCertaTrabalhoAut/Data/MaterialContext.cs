﻿using Microsoft.EntityFrameworkCore;
using ProgramacaoCertaTrabalhoAut.Models;

namespace ProgramacaoCertaTrabalhoAut.Data
{
    public class MaterialContext : DbContext
    {
        public MaterialContext(DbContextOptions options) : base (options) { }    
        public DbSet <Categoria> Categoria { get; set; }
        public DbSet<CCompras> CCompras { get; set; }
        public DbSet<Clientes> Clientes { get; set; }
        public DbSet<Fornecedor> Fornecedor { get; set; }
        public DbSet<ItensVendas> ItensVendas { get; set; }
        public DbSet<MovimenItem> MovimenItem { get; set; }
        public DbSet<Movimentacao> Movimentacao { get; set; }
        public DbSet<Produtos> Produtos { get; set; }
        public DbSet<Relatorio> Relatorio { get; set; }
        public DbSet<VendasC> VendasC { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Clientes>().ToTable("tbClientes");
            modelBuilder.Entity<Fornecedor>().ToTable("tbFornecedor");
            modelBuilder.Entity<Categoria>().ToTable("tbCategoria");
            modelBuilder.Entity<Produtos>().ToTable("tbProdutos");
            modelBuilder.Entity<VendasC>().ToTable("tbCVendas");
            modelBuilder.Entity<CCompras>().ToTable("tbCCompras");
            modelBuilder.Entity<Movimentacao>().ToTable("tbMovimentacao");
            modelBuilder.Entity<Relatorio>().ToTable("tbRelatorioP");
            modelBuilder.Entity<MovimenItem>().ToTable("tbMovimenItem");
            modelBuilder.Entity<ItensVendas>().ToTable("tbItensVendas");
        }  
    }
}
